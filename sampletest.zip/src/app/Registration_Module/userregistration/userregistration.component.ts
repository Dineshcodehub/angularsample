import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { MustMatch } from './must_match.validator';

@Component({
  selector: 'app-userregistration',
  templateUrl: './userregistration.component.html',
  styleUrls: ['./userregistration.component.scss']
})
export class UserregistrationComponent implements OnInit {

  registerationForm: any;
  submitted = false;
  show_password: Boolean = false;
  show_confirm_password: Boolean = false
  constructor(private formBuilder: FormBuilder,private router:Router) { }

  ngOnInit(): void {



    this.registerationForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      mobile: ['', [Validators.required, Validators.minLength(10)]],
      confirmPassword: ['', [Validators.required, Validators.minLength(8)]],
      address: ['', Validators.required],
      gender:['',Validators.required]
    },
    
    {
     
      validator: MustMatch('password', 'confirmPassword')
    }
    );
   
  }

  get f() { return this.registerationForm.controls; }

  onSubmit() {
    this.submitted = true;

    if (this.registerationForm.invalid) {
      return;
    }

    alert('success====>' + JSON.stringify(this.registerationForm.value))

    this.router.navigate(['/datagrid']);
  }

}
