import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { DataTablesModule } from 'angular-datatables';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { UserregistrationComponent } from './Registration_Module/userregistration/userregistration.component';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './Login_Module/login/login.component';
import { DataGridAPIComponent } from './User_Module/data-grid-api/data-grid-api.component';


@NgModule({
  declarations: [
    AppComponent,
    UserregistrationComponent,
    LoginComponent,
    DataGridAPIComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,


    DataTablesModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
