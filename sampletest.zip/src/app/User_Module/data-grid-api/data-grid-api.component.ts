import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from "@angular/forms";
import { HttpClient } from '@angular/common/http';
import { UserserviceService } from '../../userservice.service'

@Component({
  selector: 'app-data-grid-api',
  templateUrl: './data-grid-api.component.html',
  styleUrls: ['./data-grid-api.component.scss']
})
export class DataGridAPIComponent implements OnInit {

  private _url: string = "https://jsonplaceholder.typicode.com/posts";

  dataGridTable :Boolean =false;

  btnhide:Boolean=true;

  tableGridData: any;

  constructor(private servicetype: UserserviceService) { }

  ngOnInit(): void {


  }
  getComments() {


    this.servicetype.getComments().subscribe(data => {

      this.dataGridTable=true

      this.tableGridData = data;
      console.log(this.tableGridData);
    });

  }

}
