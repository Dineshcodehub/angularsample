import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataGridAPIComponent } from './data-grid-api.component';

describe('DataGridAPIComponent', () => {
  let component: DataGridAPIComponent;
  let fixture: ComponentFixture<DataGridAPIComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DataGridAPIComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DataGridAPIComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
