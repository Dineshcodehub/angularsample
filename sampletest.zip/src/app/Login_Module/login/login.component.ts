import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  submitted = false;
  appForm!: FormGroup;

  constructor(private formBuilder: FormBuilder,private router:Router) { }

  ngOnInit(): void {
    this.appForm = this.setAppForm();
  }
  setAppForm() {
    return this.formBuilder.group({
     
      email: ['', [Validators.required]],
      password: ['', [Validators.required]]
    });
  }

  get f() {
    return this.appForm.controls;
  }

  login(values:any){
    this.submitted = true;
    if (this.appForm.invalid) {
   return alert("Please Enter all required Fields ! ");

    } else {

      if(values.email =="godb.com"){
        if(values.password =="123"){
          alert("Logged in Successfully ");
          this.router.navigate(['/datagrid']);

        }else{
          alert("Password is Invalid ! ");
        }
      }else if(values.password =="123"){
          if(values.email =="godb.com"){
            alert("Logged in Successfully ! ");
            this.router.navigate(['/datagrid']);

          }else{
            alert("Email is Invalid ! ");
          }
        }else{
          alert("Email or Password are Invalid ! ");
      }


    }



  }
}
