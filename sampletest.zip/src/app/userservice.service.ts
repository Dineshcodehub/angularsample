import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { filter } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  private _url = "https://jsonplaceholder.typicode.com/posts";

  constructor(private http: HttpClient) { }

  getComments() {
    return this.http.get(this._url);

  }
}
