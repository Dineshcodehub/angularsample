export class AppConstants {

    public static get SUCCESS(): string { return "SUCCESS" };

    public static get baseURL(): string { return "http://localhost:1010/"; }

    public static get NEW(): string { return "NEW"; }

    public static get EDIT(): string { return "EDIT"; }

    public static get SAVE_BRANCH(): string { return this.baseURL + "saveApplicationMaster"; }

    public static get GET_ALL_BRANCH(): string { return this.baseURL + "getAllBranch"; }


}