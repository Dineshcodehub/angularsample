import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from "@angular/forms";
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2'


import { AppConstants } from "../../../constants/AppConstants";

@Component({
  selector: 'app-branch',
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.scss']
})
export class BranchComponent implements OnInit {

  tableGrid: Boolean = true;

  tableGridData: any[] = [];

  title: String = "Branch Master";

  form: Boolean = false;

  formDeatils = new FormGroup({

    branchCode: new FormControl(''),
    branchName: new FormControl(''),
    parentBranchCode: new FormControl(''),
    status: new FormControl(''),
    action: new FormControl(AppConstants.NEW),

  })

  constructor(private http: HttpClient) {

    this.getAllBranch();

  }

  ngOnInit(): void {

  }


  showForm() {

    this.title = "Add / Edit Branch";

    this.form = true;
    this.tableGrid = false;

  }

  showGrid() {

    this.title = "Branch Master";

    this.form = false;
    this.tableGrid = true;

  }

  getAllBranch() {

    this.http.get(AppConstants.GET_ALL_BRANCH).subscribe(data => {

      this.tableGridData = data['responseDto'];

    })

  }

  save() {

    console.log(this.formDeatils.value);

    this.http.post(AppConstants.SAVE_BRANCH, this.formDeatils.value).subscribe((data) => {

      if (data['status'] == AppConstants.SUCCESS) {

        Swal.fire({
          icon: 'success',
          title: '',
          text: data['msg'],
        }).then((result) => {
          if (result.isConfirmed) {

            this.getAllBranch();
            this.showGrid();

          } else if (result.isDenied) {

          }
        })

      } else {

        Swal.fire({
          icon: 'error',
          title: '',
          text: data['exceptionMsg'],
        })

      }

      console.log("res" + JSON.stringify(data))
    });



  }


  editBranch(input) {

    this.showForm();

    this.formDeatils.patchValue(
      {
        branchCode: input.branchCode,
        branchName: input.branchName,
        parentBranchCode: input.branchCode,
        action: AppConstants.EDIT,
        status: input.status,
      }
    );

  }


}
